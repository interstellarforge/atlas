# ATLAS — Brand & Artwork Assets

Separate artwork files for Atlas by Interstellarforge. Visual direction: dark midnight-blue Saturn/moon imagery, pale ice-blue light mode and subtle white/amber/cyan rim lighting. **No artwork dependency is required.**

## Ready-to-use assets

| Location | File group | Size | Preferred format | Usage |
|---|---|---:|---|---|
| Horizontal wordmark | `logo/atlas-logo-horizontal-{dark,light}.png` | 1600×380 | PNG | Header and branding; original concept crop with baked dark/light background |
| App icon | `app-icons/atlas-app-{dark,light}-1024.png` | 1024×1024 | PNG | App icons and PWA assets; resized from approved concept art |
| Favicons | `app-icons/atlas-app-{dark,light}-{16,32,48,64,128,256,512}.png`, `.ico` | various | PNG/ICO | Browser/favicon |
| Wide page hero | `headers/atlas-hero-{dark,light}-2400x600.webp` | 2400×600 | WebP | PageHero, ProjectView (text overlay on left) |
| Compact header | `headers/atlas-page-header-{dark,light}-1400x350.webp` | 1400×350 | WebP | Smaller headers |
| Login illustration | `login/atlas-login-{dark,light}-1600x2000.webp` | 1600×2000 | WebP | Decorative left login split-panel |
| Sidebar promo | `sidebar/atlas-sidebar-{dark,light}-800x600.webp` | 800×600 | WebP | Sidebar tile |
| Project card covers | `projects/atlas-project-{blue,purple,green,orange,pink,cyan}-1280x720.webp` | 1280×720 | WebP | Lazy-loaded project cover variations |

All named image assets are provided as individual images, not as a single collage. PNG and optimized WebP are both included for artwork. `preview.png` is only a contact sheet.

## Integration into Svelte/Vite

Place chosen individual assets in `web/src/assets/atlas/`, import with Vite so your build emits hashed filenames:

```svelte
<script lang="ts">
  import heroDark from '$lib/assets/atlas/headers/atlas-hero-dark-2400x600.webp';
  import heroLight from '$lib/assets/atlas/headers/atlas-hero-light-2400x600.webp';
  // Adapt the imports to the actual Vite alias/path in your repo.
</script>

<picture>
  <source media="(prefers-color-scheme: light)" srcset={heroLight} />
  <img src={heroDark} width="2400" height="600" alt="" decoding="async" fetchpriority="high" />
</picture>
```

`prefers-color-scheme` only mirrors OS preference; if Atlas has its own theme toggle, select image based on the active app theme instead. Use `loading="lazy" decoding="async"` on project tiles below the fold; do not lazy-load the above-fold hero. Set rendered dimensions with CSS (e.g. `width: 100%; height: 100%; object-fit: cover;`) and preserve aspect ratio or reserve container dimensions to avoid CLS. For decorative art use `alt=""`.

## Performance caveat

The WebP masters have file-size targets for a **single image**, not a guarantee that a page with multiple project cards is under the 250 kB aggregate artwork cap. Lazy-load below-fold project cards and verify network total with browser DevTools. The image source artwork was generated through image tooling; some light-mode and project variants are **upscaled crops from previously approved concept boards**, so the dimensions above are output dimensions, not native generation resolution. For final retina-critical use, consider native high-resolution regeneration of these particular variants.

No new front-end dependency; no screenshot sheet as production artwork; nothing fetched from an external image host.
